from build123d import *
from ocp_vscode import show
import csv
import math
import os

# -------- FILE --------
csv_path = os.path.expanduser("~/Desktop/plate_shield2.x.csv")

# -------- READ --------
points = []
with open(csv_path, "r") as f:
    reader = csv.DictReader(f)
    for row in reader:
        points.append((float(row["X"]), float(row["Y"])))

# -------- SORT --------
cx = sum(p[0] for p in points) / len(points)
cy = sum(p[1] for p in points) / len(points)

outer = sorted(points, key=lambda p: math.atan2(p[1]-cy, p[0]-cx))

# -------- HOLES (center, bottom radius, top radius) --------
holes = [
    (-33.4383, 60, 1, 2),   # (x, y, bottom_r, top_r)
    (57, 21.7686, 1, 2),
    (57.5617, -60, 1, 2),
    (0.28, -74.5803, 1, 2),
    (-45.5294, -58.7000, 1.25, 2.5),
    (-32.0294, -55.2000, 1.25, 2.5),
    (-58.0209, -32.3463, 1, 2),
    (-56.4383, 17, 1, 2)
]

# -------- BUILD --------
with BuildPart() as part:

    # OUTER
    with BuildSketch() as s:
        with BuildLine():
            Polyline(*outer, close=True)
        make_face()

    extrude(s.face(), amount=4)

    # -------- TAPERED HOLES (LOFT CUT) --------
    for hx, hy, r_bot, r_top in holes:

        # bottom circle (2mm dia → r=1)
        with BuildSketch(Plane.XY):
            with Locations((hx, hy)):
                Circle(r_bot)

        # top circle (4mm dia → r=2)
        with BuildSketch(Plane.XY.offset(4)):
            with Locations((hx, hy)):
                Circle(r_top)

        # loft cut
        loft(mode=Mode.SUBTRACT)

# -------- SHOW --------
show(part.part, reset_camera=True)

# -------- EXPORT --------
stl_path = csv_path.replace(".csv", ".stl")
export_stl(part.part, stl_path)

print("✅ FINAL STL with tapered holes saved at:", stl_path)