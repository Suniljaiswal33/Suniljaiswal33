import ezdxf
import math
import os

# -------- CHECK CURRENT DIRECTORY --------
print("Running from:", os.getcwd())

# -------- LOAD DXF (FULL PATH USE KAR) --------
dxf_path = "/Users/softage/Desktop/point.dxf"
doc = ezdxf.readfile(dxf_path)
msp = doc.modelspace()

points = []

# -------- EXTRACT POINTS --------
for e in msp.query("POINT"):
    x, y, z = e.dxf.location
    points.append((x, y))

# -------- LWPOLYLINE --------
for e in msp.query("LWPOLYLINE"):
    for p in e.get_points():
        points.append((p[0], p[1]))

# -------- POLYLINE --------
for e in msp.query("POLYLINE"):
    for v in e.vertices:
        x, y, z = v.dxf.location
        points.append((x, y))

# -------- SPLINE --------
for e in msp.query("SPLINE"):
    for p in e.control_points:
        points.append((p[0], p[1]))

# -------- REMOVE DUPLICATES --------
points = list(set(points))
print("Total points found:", len(points))

# -------- CENTER CALCULATION --------
cx = sum(x for x, y in points) / len(points)
cy = sum(y for x, y in points) / len(points)

# -------- SORT (BOUNDARY ORDER) --------
points_sorted = sorted(points, key=lambda p: math.atan2(p[1] - cy, p[0] - cx))

# -------- SAVE CSV --------
output_path = "/Users/softage/Desktop/ordered_points.csv"

with open(output_path, "w") as f:
    for x, y in points_sorted:
        f.write(f"{x},{y}\n")

print("✅ DONE!")
print("CSV saved at:", output_path)