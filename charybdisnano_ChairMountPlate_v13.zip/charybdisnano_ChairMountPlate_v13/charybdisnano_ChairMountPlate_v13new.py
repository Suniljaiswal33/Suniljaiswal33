from build123d import *
from ocp_vscode import show

# ---------------- LOAD CSV ----------------
pts = []
with open("/Users/softage/Desktop/ordered_points.csv", "r") as f:
    for line in f:
        x, y = map(float, line.strip().split(","))
        pts.append((x, y))

print("Total points:", len(pts))

# ---------------- CENTER SHIFT ----------------
cx = sum(x for x, y in pts) / len(pts)
cy = sum(y for x, y in pts) / len(pts)

pts = [(x - cx, y - cy) for x, y in pts]

# ---------------- BASE PLATE ----------------
with BuildPart() as part:
    with BuildSketch():
        with BuildLine():
            Polyline(pts, close=True)
        make_face()

    extrude(amount=4)   # plate thickness

# ---------------- BOX ADD ----------------
bbox = part.part.bounding_box()

xmax = bbox.max.X
ymin = bbox.min.Y

# 👉 tuned position (edge align + thoda andar)
box_x = xmax - 30
box_y = ymin + 35

with BuildPart() as final:
    add(part.part)

    with BuildSketch(Plane.XY):
        with Locations((box_x + 15, box_y + 15)):
            Rectangle(30, 30)

    extrude(amount=-20)   # box downward

final_part = final.part

# ---------------- SHOW ----------------
show(final_part)